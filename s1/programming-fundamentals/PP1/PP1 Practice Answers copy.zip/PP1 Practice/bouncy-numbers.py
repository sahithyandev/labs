DIGITS = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]


def is_increasing(n: int):
    digits = list(str(n))
    last_index = DIGITS.index(digits[0])
    for digit_index in range(1, len(digits)):
        current_index = DIGITS.index(digits[digit_index])
        if last_index > current_index:
            return False
        last_index = current_index
    return True


def is_decreasing(n: int):
    digits = list(str(n))
    last_index = DIGITS.index(digits[0])
    for digit_index in range(1, len(digits)):
        current_index = DIGITS.index(digits[digit_index])
        if last_index < current_index:
            return False
        last_index = current_index
    return True


[starting, ending] = map(int, input().split())
total = 0
for n in range(starting, ending+1):
    if is_increasing(n) or is_decreasing(n):
        continue
    total += n

print(total)
